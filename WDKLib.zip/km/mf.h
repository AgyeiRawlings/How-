/*++

Copyright (c) 1997 Microsoft Corporation

Module Name:

    mf.h

Abstract:

    This header describes the structures and interfaces required to interact
    with the multifunction enumerator.

Author:

Revision History:

--*/


#if !defined(_MF_)
#define _MF_

//
// MfFlags value
//

#define MF_FLAGS_EVEN_IF_NO_RESOURCE            0x00000001
#define MF_FLAGS_NO_CREATE_IF_NO_RESOURCE       0x00000002
#define MF_FLAGS_FILL_IN_UNKNOWN_RESOURCE       0x00000004
#define MF_FLAGS_CREATE_BUT_NO_SHOW_DISABLED    0x00000008

typedef struct _MF_RESOURCE_MAP {

    ULONG Count;
    UCHAR Resources[ANYSIZE_ARRAY];

} MF_RESOURCE_MAP, *PMF_RESOURCE_MAP;


typedef struct _MF_VARYING_RESOURCE_ENTRY {

    UCHAR ResourceIndex;
    UCHAR Reserved[3];      // Packing
    ULONG Offset;
    ULONG Size;
    ULONG MaxCount;

} MF_VARYING_RESOURCE_ENTRY, *PMF_VARYING_RESOURCE_ENTRY;


typedef struct _MF_VARYING_RESOURCE_MAP {

    ULONG Count;
    MF_VARYING_RESOURCE_ENTRY Resources[ANYSIZE_ARRAY];

} MF_VARYING_RESOURCE_MAP, *PMF_VARYING_RESOURCE_MAP;


typedef struct _MF_DEVICE_INFO *PMF_DEVICE_INFO;

typedef struct _MF_DEVICE_INFO {

    //
    // Name for this child, unique with respect to the other children
    //
    UNICODE_STRING Name;

    //
    // A REG_MULTI_SZ style list of hardware IDs
    //
    UNICODE_STRING HardwareID;

    //
    // A REG_MULTI_SZ style list of compatible IDs
    //
    UNICODE_STRING CompatibleID;

    //
    // Map of resource that we totally consume
    //
    PMF_RESOURCE_MAP ResourceMap;

    //
    // Map of resource that we partially consume
    //
    PMF_VARYING_RESOURCE_MAP VaryingResourceMap;

    //
    // Flags -
    //      MF_FLAGS_FILL_IN_UNKNOWN_RESOURCE - if the parent resource doesn't
    //          contain a descriptor referenced in the ResourceMap use a
    //          null (CmResourceTypeNull) descriptor instead.
    //
    ULONG MfFlags;

} MF_DEVICE_INFO;

typedef
_Function_class_(MF_ENUMERATE_CHILD)
NTSTATUS
MF_ENUMERATE_CHILD(
    _In_opt_ PVOID Context,
    _In_ ULONG Index,
    _Out_
        _At_(ChildInfo->Name.Buffer,         __drv_allocatesMem(Mem))
        _At_(ChildInfo->HardwareID.Buffer,   __drv_allocatesMem(Mem))
        _At_(ChildInfo->CompatibleID.Buffer, __drv_allocatesMem(Mem))
        _At_(ChildInfo->ResourceMap,         __drv_allocatesMem(Mem))
        _At_(ChildInfo->VaryingResourceMap,  __drv_allocatesMem(Mem))
        PMF_DEVICE_INFO ChildInfo
    );
typedef MF_ENUMERATE_CHILD *PMF_ENUMERATE_CHILD;

/*++


Routine Description:

    This returns information about children to be enumerated by a multifunction
    driver.

Arguments:

    Context - Context from the MF_ENUMERATION_INTERFACE

    Index - Zero based index of the children

    ChildInfo - Pointer to a caller allocated buffer that should be filled in
        by the callee.  This will involve allocation of extra buffers for each
        piece of information.  These will be freed by calling ExFreePool when
        they are no longer required.

Return Value:

    Status code that indicates whether or not the function was successful.

    STATUS_NO_MORE_ENTRIES indicates that the are no more children to enumerate

--*/

typedef struct _MF_ENUMERATION_INTERFACE {

    //
    // Generic interface header
    //
    USHORT Size;
    USHORT Version;
    PVOID Context;
    PINTERFACE_REFERENCE InterfaceReference;
    PINTERFACE_DEREFERENCE InterfaceDereference;

    //
    // Multi-function enumeration data
    //
    PMF_ENUMERATE_CHILD EnumerateChild;

} MF_ENUMERATION_INTERFACE, *PMF_ENUMERATION_INTERFACE;

#endif

