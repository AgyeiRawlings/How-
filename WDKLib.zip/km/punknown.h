/*****************************************************************************
 * punknown.h - IUnknown definitions
 *****************************************************************************
 * Copyright (c) Microsoft Corporation. All rights reserved.
 */

#ifndef _UNKNOWN_H_
#define _UNKNOWN_H_

#ifdef __cplusplus
extern "C" {
#include <wdm.h>
}
#else
#include <wdm.h>
#endif

#include <windef.h>
#define COM_NO_WINDOWS_H
#include <basetyps.h>
#ifdef PUT_GUIDS_HERE
#include <initguid.h>
#endif


DEFINE_GUID(IID_IUnknown,
0x00000000, 0x0000, 0x0000, 0x00, 0x00, 0xc0, 0x00, 0x00, 0x00, 0x00, 0x46);

/*****************************************************************************
 * IUnknown
 *****************************************************************************
 * Base interface for otherwise unknown objects.
 */
#undef INTERFACE
#define INTERFACE IUnknown
DECLARE_INTERFACE(IUnknown)
{
    STDMETHOD_(NTSTATUS,QueryInterface)
    (   THIS_
        _In_            REFIID,
        _COM_Outptr_    PVOID *
    )   PURE;

    STDMETHOD_(ULONG,AddRef)
    (   THIS
    )   PURE;

    STDMETHOD_(ULONG,Release)
    (   THIS
    )   PURE;
};
#undef INTERFACE

typedef IUnknown *PUNKNOWN;

/*****************************************************************************
 * PFNCREATEINSTANCE
 *****************************************************************************
 * Type for object create function.
 */
typedef
HRESULT
(*PFNCREATEINSTANCE)
(
    _Out_ PUNKNOWN *  Unknown,
    _In_  REFCLSID    ClassId,
    _In_  PUNKNOWN    OuterUnknown,
    _In_  POOL_TYPE   PoolType
);





#endif
